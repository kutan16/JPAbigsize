package com.cg.billing.beans;

import javax.persistence.Embeddable;

@Embeddable
public class Dish {
	private int starter;
	private int mainCourse;
	private int desert;
	private float sGst=(float) 0.09;
	private float cGst=(float) 0.09;

	public Dish() {}

	
	public Dish(int starter, int mainCourse, int desert) {
		super();
		this.starter = starter;
		this.mainCourse = mainCourse;
		this.desert = desert;
	}
	

	public Dish(int starter, int mainCourse, int desert, int sGst, int cGst) {
		super();
		this.starter = starter;
		this.mainCourse = mainCourse;
		this.desert = desert;
		this.sGst = sGst;
		this.cGst = cGst;
	}


	public int getStarter() {
		return starter;
	}

	public void setStarter(int starter) {
		this.starter = starter;
	}

	public int getMainCourse() {
		return mainCourse;
	}

	public void setMainCourse(int mainCourse) {
		this.mainCourse = mainCourse;
	}

	public int getDesert() {
		return desert;
	}

	public void setDesert(int desert) {
		this.desert = desert;
	}

	public float getsGst() {
		return sGst;
	}

	public void setsGst(int sGst) {
		this.sGst = sGst;
	}

	public float getcGst() {
		return cGst;
	}

	public void setcGst(int cGst) {
		this.cGst = cGst;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		float result = 1;
		result = prime * result + cGst;
		result = prime * result + desert;
		result = prime * result + mainCourse;
		result = prime * result + sGst;
		result = prime * result + starter;
		return (int) result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Dish other = (Dish) obj;
		if (cGst != other.cGst)
			return false;
		if (desert != other.desert)
			return false;
		if (mainCourse != other.mainCourse)
			return false;
		if (sGst != other.sGst)
			return false;
		if (starter != other.starter)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Dish [starter=" + starter + ", mainCourse=" + mainCourse + ", desert=" + desert + ", sGst=" + sGst
				+ ", cGst=" + cGst + "]";
	}
	
}