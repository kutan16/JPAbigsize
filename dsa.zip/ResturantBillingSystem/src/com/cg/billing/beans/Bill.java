package com.cg.billing.beans;

import javax.persistence.Embeddable;

@Embeddable
public class Bill {
	private int billNo;
	private int billAmount;
	public Bill() {}
	
	public Bill(int billNo) {
		super();
		this.billNo = billNo;
	}

	public Bill(int billNo, int billAmount) {
		this.billNo = billNo;
		this.billAmount = billAmount;
	}
	public int getBillNo() {
		return billNo;
	}
	public void setBillNo(int billNo) {
		this.billNo = billNo;
	}
	public int getBillAmount() {
		return billAmount;
	}
	public void setBillAmount(int billAmount) {
		this.billAmount = billAmount;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + billAmount;
		result = prime * result + billNo;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Bill other = (Bill) obj;
		if (billAmount != other.billAmount)
			return false;
		if (billNo != other.billNo)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Bill [billNo=" + billNo + ", billAmount=" + billAmount + "]";
	}
	
	
}