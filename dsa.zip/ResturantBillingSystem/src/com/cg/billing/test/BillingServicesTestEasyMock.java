package com.cg.billing.test;

import static org.junit.Assert.*;
import java.util.ArrayList;
import org.easymock.EasyMock;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.billing.beans.Bill;
import com.cg.billing.beans.Customer;
import com.cg.billing.beans.Dish;
import com.cg.billing.daoservices.CustomerDAO;
import com.cg.billing.exceptions.CustomerDetailsNotFoundException;
import com.cg.billing.services.BillingServices;
import com.cg.billing.services.BillingServicesImpl;

public class BillingServicesTestEasyMock {
	private static BillingServices billingServices;
	private static CustomerDAO mockCustomerDao;

	@BeforeClass
	public static void setUpTestEnv() {
		mockCustomerDao=EasyMock.mock(CustomerDAO.class);
		billingServices=new BillingServicesImpl(mockCustomerDao);
	}

	@Before
	public void setUpTestMockData() {
		Customer customer1=new Customer("frank","castle","castle@mcu.com",9876,new Dish(120,100,200),new Bill((int) (Math.random()*100+34)));
		Customer customer2=new Customer("dinah","madani","madani@mcu.com",9877,new Dish(211,109,208),new Bill((int) (Math.random()*100+85)));
		Customer customer3=new Customer("john","pilgrim","pilgrim@mcu.com",9878,new Dish(140,125,207),new Bill((int) (Math.random()*100+78)));
		ArrayList<Customer>customersList=new ArrayList<Customer>();
		customersList.add(customer1);
		customersList.add(customer2);
		EasyMock.expect(mockCustomerDao.save(customer3)).andReturn(customer3);
		
		EasyMock.expect(mockCustomerDao.findOne(101)).andReturn(customer1);
		EasyMock.expect(mockCustomerDao.findOne(102)).andReturn(customer2);
		EasyMock.expect(mockCustomerDao.findOne(1234)).andReturn(null);
		EasyMock.expect(mockCustomerDao.findAll()).andReturn(customersList);
		EasyMock.replay(mockCustomerDao);
	}
	
	@Test(expected=CustomerDetailsNotFoundException.class)
	public void testGetCustomerDataForInvalidCustomerId() throws CustomerDetailsNotFoundException {
		billingServices.getCustomerDetails(1234);
		EasyMock.verify(mockCustomerDao.findOne(1234));
	}
	
	@Test(expected=CustomerDetailsNotFoundException.class)
	public void testGetCustomerDataForValidCustomerId() throws CustomerDetailsNotFoundException {
		Customer expectedCustomer = new Customer("frank","castle","frank@mcu.com",9876,new Dish(120,100,200),new Bill((int) (Math.random()*100+34)));
		//expectedCustomer.setCustomerId(101);
		Customer actualCustomer=billingServices.getCustomerDetails(101);
		assertEquals(expectedCustomer, actualCustomer);
		EasyMock.verify(mockCustomerDao.findOne(101));
	}
	
	@After
	public void tearDownTestMockData() {
		EasyMock.resetToDefault(mockCustomerDao);
	}
	
	@AfterClass
	public static void tearDownTestEnv() {
		mockCustomerDao=null;
		billingServices=null;
	}
}
