package com.cg.banking.test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.HashMap;

import org.easymock.EasyMock;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

public class BankingServicesTestEasyMock {
	private static BankingServices bankingServices;
	private static AccountDAO mockAccountDao;
	@BeforeClass
	public static void setUpTestEnv() {
		mockAccountDao=EasyMock.mock(AccountDAO.class);
		bankingServices=new BankingServicesImpl(mockAccountDao);
	}
	@Before
	public void setUpTestMockData() {
		Account account1=new Account(5001, 1234, "Savings", "Active", 5000,new HashMap<Integer, Transaction>(1));
		Account account2=new Account(5002, 2345, "Savings", "Blocked", 10000,new HashMap<Integer, Transaction>(1));
		ArrayList<Account>accountList=new ArrayList<Account>();
		accountList.add(account1);
		accountList.add(account2);
		EasyMock.expect(mockAccountDao.save(account2)).andReturn(account2);
		EasyMock.expect(mockAccountDao.findOne(101)).andReturn(account1);
		EasyMock.expect(mockAccountDao.findOne(102)).andReturn(account2);
		EasyMock.expect(mockAccountDao.findOne(1234)).andReturn(null);
		EasyMock.expect(mockAccountDao.findAll()).andReturn(accountList);
		EasyMock.replay(mockAccountDao);
	}
	@Test(expected=AccountNotFoundException.class)
	public void testGetAssociateDataForInvalidAccountNumber() throws AccountNotFoundException, BankingServicesDownException {
		bankingServices.getAccountDetails(1234);
		EasyMock.verify(mockAccountDao.findOne(1234));
	}
	@Test(expected=AccountNotFoundException.class)
	public void testGetAssociateDataForValidAssociateId() throws AccountNotFoundException, BankingServicesDownException {
		Account expectedAccount = new Account(5001, 1234, "Savings", "Active", 5000,new HashMap<Integer, Transaction>(1));
		Account actualAccount=bankingServices.getAccountDetails(101);
		assertEquals(expectedAccount, actualAccount);
		EasyMock.verify(mockAccountDao.findOne(101));
	}
	@After
	public void tearDownTestMockData() {
		EasyMock.resetToDefault(mockAccountDao);
	}
	@AfterClass
	public static void tearDownTestEnv() {
		mockAccountDao=null;
		bankingServices=null;
	}

}
