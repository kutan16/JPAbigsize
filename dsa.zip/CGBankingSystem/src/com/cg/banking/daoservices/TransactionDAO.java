package com.cg.banking.daoservices;
import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;

public interface TransactionDAO {
	Transaction save(Account account,long accountNo,Transaction transaction);
	boolean update(long accountNo,Transaction  transaction);
	Transaction findOne(long accountNo,int transactionId);
	List<Transaction>findAll(long accountNo);
}
