package com.cg.banking.daoservices;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cg.banking.beans.Account;

public  class AccountDAOImpl implements AccountDAO{
	private EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("JPA-PU");
	@Override
	public Account save(Account account) {
		
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(account);
		entityManager.getTransaction().commit();
		entityManager.close();
		return account;
	}

	@Override
	public boolean update(Account account) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.merge(account);
		entityManager.getTransaction().commit();
		entityManager.close();

		return false;
	}

	@Override
	public Account findOne(long accountNo) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		return entityManager.find(Account.class, accountNo);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Account> findAll() {
		Query query=entityManagerFactory.createEntityManager().createQuery("from Account a");
		return (List<Account>)query.getResultList();
	}

	
	
//	@Override
//	public Account save(Account account) {
//		account.setAccountNo(BankingDBUtil.getACCOUNT_ID_COUNTER());
//		account.setAccountStatus(BankingDBUtil.getAccountStatus());
//		account.setPinNumber(BankingDBUtil.getPin());
//		BankingDBUtil.accountDetails.put(account.getAccountNo(),account);
//		BankingDBUtil.accountDetails.put((long) account.getPinNumber(), account);
//		return account;
//	}
//	@Override
//	public boolean update(Account account) {
//		return false;
//	}
//	@Override
//	public Account findOne(long accountNo) {
//		return BankingDBUtil.accountDetails.get(accountNo);
//	}
//	@Override
//	public List<Account> findAll() {
//		return new ArrayList<Account>(BankingDBUtil.accountDetails.values());
//	}
}