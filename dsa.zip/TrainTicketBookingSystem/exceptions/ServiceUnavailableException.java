package com.cg.ticketing.exceptions;

public class ServiceUnavailableException extends Exception {
	public ServiceUnavailableException() {
System.out.println("Service Is UnAvailable");	}

}
